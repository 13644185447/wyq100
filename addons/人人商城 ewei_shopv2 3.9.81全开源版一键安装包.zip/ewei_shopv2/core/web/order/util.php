<?php
if (!defined('IN_IA')) {
	exit('Access Denied');
}

class Util_EweiShopV2Page extends WebPage
{}

?>
